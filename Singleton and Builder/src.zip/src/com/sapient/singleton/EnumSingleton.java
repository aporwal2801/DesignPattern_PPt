package com.sapient.singleton;

public enum EnumSingleton {

	INSTANCE;

	public static void doSomething() {
		// do something
	}
}
