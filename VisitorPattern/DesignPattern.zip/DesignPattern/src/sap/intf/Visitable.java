package sap.intf;

public interface Visitable{

	  public float accept(Visitor visitor);

	}